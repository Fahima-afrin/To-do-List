var dt = new Date();
var timeElement = document.getElementById("datetime");
timeElement.innerHTML = dt.toLocaleString();
timeElement.style.color = "black"; // Set time color to black